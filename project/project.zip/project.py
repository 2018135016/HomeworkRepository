import project_functions

location = ""

project_functions.data_processing(location)
project_functions.data_generation(location)
project_functions.print_graph(location, 'gulim')